class Line:
    def __init__(self, lineId, lineSize, lineSpeed):
        self.lineId = lineId  # the ID used by the canvas
        self.lineSize = lineSize
        self.lineSpeed = lineSpeed
