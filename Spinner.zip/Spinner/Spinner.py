import tkinter as tk
import lineClass
import math

# global variables
w, h = 700, 500


class Application(tk.Frame):

    def __init__(self, canvas):
        super().__init__()
        self.canvas = canvas
        self.mouseIsPressed = False

        self.s = 0  # sin value for rotating lines
        self.c = 0  # cos value for rotating lines

        # setting lastX and lastY to None prevents lines skipping when changing the amount of lines etc
        self.lastX = None  # last x-coordinate where a pixel was drawn
        self.lastY = None  # last y-coordinate where a pixel was drawn

        self.interval = 5  # interval for drawing

        self.initUI()
        self.lineList = []  # list of moving liens
        self.drawList = []  # list of drawn lines

        self.startSpin()

    def initUI(self):
        print("Initializing UI...")

        btnQuit = tk.Button(text="Clear canvas", command=self.clearCanvas)
        btnQuit.pack(side=tk.TOP)

        btnAdd = tk.Button(text="Add line", command=self.addLines)
        btnAdd.pack(side=tk.TOP)

        btnClear = tk.Button(text="Remove line", command=self.removeLine)
        btnClear.pack(side=tk.TOP)

        lblSize = tk.Label(text="Line size: (5 to 50)")
        lblSize.pack(side=tk.TOP)

        self.eSize = tk.Entry()
        self.eSize.pack(side=tk.TOP)

        lblSpeed = tk.Label(text="Line speed: (-100 to 100)")
        lblSpeed.pack(side=tk.TOP)

        self.eSpeed = tk.Entry()
        self.eSpeed.pack(side=tk.TOP)

        self.listbox = tk.Listbox(width=25)
        self.listbox.place(x=60, y=0)

        self.canvas.bind("<Motion>", self.mouseMoved)
        self.canvas.bind("<Button-1>", self.mousePressed)
        self.canvas.bind("<ButtonRelease-1>", self.mouseReleased)

    def addLines(self):
        if self.eSize.get() == "" or not self.eSize.get().isnumeric():
            print("Enter valid number for size")
            return

        try:
            if self.eSpeed.get() == "":
                print("Enter valid number for speed")
                return
        except:
            print("An exception occurred")
            return

        if len(self.lineList) < 8:
            print("Added line")
            size = float(self.eSize.get())
            speed = float(self.eSpeed.get()) / 100

            if not (size in range(4, 51)):
                print("Error with size, size has been set to 25")
                size = 25

            if not (-1 <= speed <= 1):
                print("Error with speed, speed has been set to 5")
                speed = 0.05

            self.createLine(size, speed)
        else:
            print("Error: max 8 lines")

    def removeLine(self):
        if not len(self.lineList) == 0:
            self.lastX, self.lastY = None, None
            self.listbox.delete(len(self.lineList) - 1)
            self.canvas.delete(self.lineList.pop().lineId)

    def clearCanvas(self):
        print("Cleared canvas")
        self.lastX, self.lastY = None, None
        for D in self.drawList:
            self.canvas.delete(D)  # delete everything on canvas except moving lines

    def createLine(self, size, speed):
        self.lastX, self.lastY = None, None
        line = lineClass.Line(0, 0, 0)
        line.lineSize = size
        line.lineSpeed = speed
        line.lineId = self.canvas.create_line(w / 2, h / 2, w / 2 + line.lineSize, h / 2 + line.lineSize, width=2.5)

        self.lineList.append(line)
        self.listbox.insert(tk.END, "Line %d, size: %g, speed: %g" % (
            self.listbox.size() + 1, line.lineSize, line.lineSpeed * 100))  # information about line displayed in box

    def startSpin(self):
        for i in range(0, len(self.lineList)):
            self.calcLineSinCos(self.lineList[i])
            self.calcLinePosition(self.lineList[i], i)
            self.calcLineRotation(self.lineList[i])
            if i == len(self.lineList) - 1 and self.mouseIsPressed:
                self.paintPixel(self.lineList[i])

        self.canvas.after(10, self.startSpin)  # calculates everything every 10 milliseconds

    def calcLineSinCos(self, line):
        self.s = math.sin(line.lineSpeed)
        self.c = math.cos(line.lineSpeed)

    def calcLinePosition(self, line, pos):
        self.s = math.sin(line.lineSpeed)
        self.c = math.cos(line.lineSpeed)
        if not (pos == 0):
            self.canvas.move(line.lineId,
                             self.canvas.coords(self.lineList[pos - 1].lineId)[2] - self.canvas.coords(line.lineId)[0],
                             self.canvas.coords(self.lineList[pos - 1].lineId)[3] - self.canvas.coords(line.lineId)[1])

    def calcLineRotation(self, line):
        xDif = self.canvas.coords(line.lineId)[2] - self.canvas.coords(line.lineId)[0]
        yDif = self.canvas.coords(line.lineId)[3] - self.canvas.coords(line.lineId)[1]

        oldX = self.canvas.coords(line.lineId)[0]
        oldY = self.canvas.coords(line.lineId)[1]

        newX = xDif * self.c - yDif * self.s + self.canvas.coords(line.lineId)[0]
        newY = xDif * self.s + yDif * self.c + self.canvas.coords(line.lineId)[1]

        self.canvas.coords(line.lineId, oldX, oldY, newX, newY)

    def paintPixel(self, line):
        if self.lastX is None or self.lastY is None:
            self.lastX, self.lastY = self.canvas.coords(line.lineId)[2], self.canvas.coords(line.lineId)[3]

        if self.interval == 5:
            newDrawing = self.canvas.create_line(self.lastX, self.lastY, self.canvas.coords(line.lineId)[2],
                                                 self.canvas.coords(line.lineId)[3],
                                                 width=1)
            self.lastX = self.canvas.coords(line.lineId)[2]
            self.lastY = self.canvas.coords(line.lineId)[3]

            self.drawList.append(newDrawing)
            self.interval = 0

        self.interval += 1

    def mouseMoved(self, event):
        if not (len(self.lineList) == 0):
            self.canvas.move(self.lineList[0].lineId, event.x - self.canvas.coords(self.lineList[0].lineId)[0],
                             event.y - self.canvas.coords(self.lineList[0].lineId)[1])

    def mousePressed(self, event):
        self.mouseIsPressed = True

    def mouseReleased(self, event):
        self.mouseIsPressed = False
        self.lastX, self.lastY = None, None


def main():
    root = tk.Tk()
    canvas = tk.Canvas(root, width=w, height=h)
    app = Application(canvas)
    canvas.pack()
    root.mainloop()


if __name__ == '__main__':
    main()
